/*	libnvs
	Copyright 2015 Jonathan Wilson

	This file is part of libnvs
	libnvs is free software; you can redistribute it and/or modify it under
	the terms of the GNU General Public License as published by the Free
	Software Foundation; either version 3, or (at your option) any later
	version. See the file COPYING for more details.
*/
#include "nvsfile.h"
int main()
{
	/*
	NVSFile *file = new NVSFile();
	if (!file->Open("autosave.ess"))
	{
		return 1;
	}
	file->Save("test.ess");
	*/
	return 0;
}

